# sftpscan-plguin
A Pentaho Data Integration plugin to enable sftp remote file scanning
